#include <iostream>
#include <vector>
#include <iomanip>

class Course {
public:
    std::string name;
    int credits;
    double grade;

    Course(std::string n, int c, double g) : name(n), credits(c), grade(g) {}
};

class CGPACalculator {
    std::vector<Course> courses;
    double totalCredits;
    double totalGradePoints;

public:
    CGPACalculator() : totalCredits(0), totalGradePoints(0) {}

    void addCourse(const Course &course) {
        courses.push_back(course);
        totalCredits += course.credits;
        totalGradePoints += course.credits * course.grade;
    }

    double calculateGPA() {
        if (totalCredits == 0) return 0.0;
        return totalGradePoints / totalCredits;
    }

    void displayCourses() {
        std::cout << "Course List:\n";
        std::cout << std::setw(15) << "Course Name"
                  << std::setw(10) << "Credits"
                  << std::setw(10) << "Grade\n";
        for (const auto &course : courses) {
            std::cout << std::setw(15) << course.name
                      << std::setw(10) << course.credits
                      << std::setw(10) << course.grade << "\n";
        }
    }

    void displayCGPA() {
        std::cout << "\nTotal Credits: " << totalCredits << "\n";
        std::cout << "Total Grade Points: " << totalGradePoints << "\n";
        std::cout << "Cumulative GPA: " << calculateGPA() << "\n";
    }
};

int main() {
    CGPACalculator calculator;
    int numCourses;

    std::cout << "Enter the number of courses: ";
    std::cin >> numCourses;

    for (int i = 0; i < numCourses; ++i) {
        std::string courseName;
        int credits;
        double grade;

        std::cout << "Enter course name: ";
        std::cin >> courseName;
        std::cout << "Enter credits for " << courseName << ": ";
        std::cin >> credits;
        std::cout << "Enter grade for " << courseName << ": ";
        std::cin >> grade;

        calculator.addCourse(Course(courseName, credits, grade));
    }

    calculator.displayCourses();
    calculator.displayCGPA();

    return 0;
}
